#include <SPI.h>
#include "motorDriver.h"

// -------- SPI --------
volatile byte receivedByte = 0;
volatile bool newData = false;

// -------- Motor --------
motorDriver motor(1, "Test Motor", 3.3, 8);

motorWiring_t wiring;
motorLimit_t limits;
dir_t direction;

// Target behavior
float targetVoltage = 1.5;   // simple movement speed
unsigned long moveTime = 1000; // ms

void setup() {
  Serial.begin(115200);

  // -------- SPI SLAVE SETUP --------
  pinMode(MISO, OUTPUT);
  SPCR |= _BV(SPE);        // Enable SPI
  SPI.attachInterrupt();   // Enable SPI interrupt

  // -------- MOTOR SETUP --------
  wiring.enablePin = 2;
  wiring.dirPin    = 3;
  wiring.pwmPin    = 4;
  wiring.FWSwitchPin = 0;
  wiring.BWSwitchPin = 0;

  limits.forwardLimit = 180;
  limits.backwardLimit = -180;
  limits.maxSpeed = 3.3;
  limits.minSpeed = 0;
  limits.maxAcc = 0;
  limits.maxTorque = 0;

  direction.FORWARD = LOW;
  direction.BACKWARD = HIGH;

  motor.init(wiring, limits);

  Serial.println("SPI Motor Controller Ready");
}

// -------- SPI INTERRUPT --------
ISR(SPI_STC_vect) {
  receivedByte = SPDR;
  newData = true;
}

// -------- MAIN LOOP --------
void loop() {
  if (newData) {
    newData = false;

    Serial.print("Received SPI: ");
    Serial.println(receivedByte, HEX);

    // -------- TRIGGER --------
    if (receivedByte == 0x01) {
      Serial.println("START COMMAND → Moving motor");

      // Move forward
      motor.rotateForward(targetVoltage, direction);
      delay(moveTime);

      // Stop motor
      motor.stop();
      motor.disable();

      Serial.println("Motion complete");
    }
  }
}